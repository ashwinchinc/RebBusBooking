package com.Unity.Mall.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Unity.Mall.dao.CustomerRepository;
import com.Unity.Mall.entity.Customer;

@Service
public class CustomerService {
	@Autowired
	CustomerRepository customerRepository; 
	public Customer createCustomer(Customer cust) {
		return customerRepository.save(cust);
	}
	public Optional<Customer> findCustomerById(Long id) {
		return customerRepository.findById(id);
	}
	public Customer updateCustomer(Customer customer , Long id) {
		Optional<Customer> opCust=customerRepository.findById(id) ;
		Customer cust=opCust.get();
		cust.setParticulars(customer.getParticulars());
		cust.setQty(customer.getQty());
		cust.setRate(customer.getRate());
		cust.setAmount(customer.getAmount());
		return customerRepository.save(cust);
	}
	public void deleteCustomer(Long id) {
		
		customerRepository.deleteById(id);
		
	}

}
